
import cv2
import mediapipe as mp
import pyautogui
import math

pyautogui.FAILSAFE = True

camera = cv2.VideoCapture(0)

mp_hands = mp.solutions.hands
draw = mp.solutions.drawing_utils

hands = mp_hands.Hands(
    max_num_hands=1,
    min_detection_confidence=0.7
)

screen_w, screen_h = pyautogui.size()
clicking = False

while True:
    success, frame = camera.read()
    if not success:
        print("Camera not detected!")
        break

    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape

    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = hands.process(rgb)

    if result.multi_hand_landmarks:
        hand = result.multi_hand_landmarks[0]

        draw.draw_landmarks(
            frame, hand, mp_hands.HAND_CONNECTIONS
        )

        index = hand.landmark[8]
        thumb = hand.landmark[4]

        x = int(index.x * screen_w)
        y = int(index.y * screen_h)

        pyautogui.moveTo(x, y)

        distance = math.hypot(
            index.x - thumb.x,
            index.y - thumb.y
        )

        if distance < 0.04 and not clicking:
            pyautogui.click()
            clicking = True
        elif distance > 0.06:
            clicking = False

        cv2.putText(
            frame, "Pinch fingers to CLICK | Q to quit",
            (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
            0.55, (0, 255, 0), 2
        )

    cv2.imshow("Hand Gesture Mouse", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

camera.release()
hands.close()
cv2.destroyAllWindows()
