
import cv2
import mediapipe as mp
import pyautogui
import math
import time

pyautogui.FAILSAFE = True

camera = cv2.VideoCapture(0)

mp_hands = mp.solutions.hands
draw = mp.solutions.drawing_utils

hands = mp_hands.Hands(
    max_num_hands=1,
    min_detection_confidence=0.7,
    min_tracking_confidence=0.7
)

screen_w, screen_h = pyautogui.size()

clicking = False
right_clicking = False
last_scroll_time = 0
scroll_delay = 0.25

while True:
    success, frame = camera.read()

    if not success:
        print("Camera not detected!")
        break

    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape

    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = hands.process(rgb)

    if result.multi_hand_landmarks:
        hand = result.multi_hand_landmarks[0]

        draw.draw_landmarks(
            frame, hand, mp_hands.HAND_CONNECTIONS
        )

        # Finger landmarks
        thumb = hand.landmark[4]
        index = hand.landmark[8]
        middle = hand.landmark[12]
        ring = hand.landmark[16]
        pinky = hand.landmark[20]

        index_tip = hand.landmark[8]
        middle_tip = hand.landmark[12]
        index_pip = hand.landmark[6]
        middle_pip = hand.landmark[10]
        ring_pip = hand.landmark[14]
        pinky_pip = hand.landmark[18]

        # Cursor movement
        x = int(index.x * screen_w)
        y = int(index.y * screen_h)
        pyautogui.moveTo(x, y)

        # Left click: thumb + index pinch
        pinch_distance = math.hypot(
            index.x - thumb.x,
            index.y - thumb.y
        )

        # Right-click gesture: index + middle fingers raised,
        # ring + pinky fingers folded
        index_up = index_tip.y < index_pip.y
        middle_up = middle_tip.y < middle_pip.y
        ring_folded = ring.y > ring_pip.y
        pinky_folded = pinky.y > pinky_pip.y

        right_gesture = (
            index_up and middle_up
            and ring_folded and pinky_folded
            and pinch_distance > 0.08
        )

        if right_gesture and not right_clicking:
            pyautogui.rightClick()
            right_clicking = True
        elif not right_gesture:
            right_clicking = False

        # Left click
        if pinch_distance < 0.04 and not clicking:
            pyautogui.click()
            clicking = True
        elif pinch_distance > 0.06:
            clicking = False

        # Scroll gesture: index + middle fingers raised,
        # ring + pinky fingers folded
        # Move the hand vertically to scroll
        current_time = time.time()

        if right_gesture and current_time - last_scroll_time > scroll_delay:
            # Scroll using hand's vertical position
            if index_tip.y < 0.30:
                pyautogui.scroll(3)
                last_scroll_time = current_time
            elif index_tip.y > 0.70:
                pyautogui.scroll(-3)
                last_scroll_time = current_time

        # Display status
        cv2.putText(
            frame,
            "Pinch: LEFT CLICK",
            (10, 30),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6, (0, 255, 0), 2
        )

        cv2.putText(
            frame,
            "2 fingers + folded others: RIGHT CLICK / SCROLL",
            (10, 60),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.48, (255, 255, 0), 2
        )

    else:
        clicking = False
        right_clicking = False

    cv2.putText(
        frame, "Q: QUIT",
        (10, frame.shape[0] - 15),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.6, (0, 0, 255), 2
    )

    cv2.imshow("Hand Gesture Mouse", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

camera.release()
hands.close()
cv2.destroyAllWindows()
